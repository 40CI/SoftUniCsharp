public abstract class Vehicle : IVehicle
{
    protected Vehicle(string brand, string model, double maxMileage, string licensePlateNumber)
    {
        if (string.IsNullOrWhiteSpace(brand)) throw new ArgumentException("Brand cannot be null or whitespace!");
        if (string.IsNullOrWhiteSpace(model)) throw new ArgumentException("Model cannot be null or whitespace!");
        if (string.IsNullOrWhiteSpace(licensePlateNumber)) throw new ArgumentException("License plate number is required!");

        Brand = brand;
        Model = model;
        MaxMileage = maxMileage;
        LicensePlateNumber = licensePlateNumber;
        BatteryLevel = 100;
        IsDamaged = false;
    }

    public string Brand { get; }
    public string Model { get; }
    public double MaxMileage { get; }
    public string LicensePlateNumber { get; }
    public int BatteryLevel { get; private set; }
    public bool IsDamaged { get; private set; }

    public void Drive(double mileage)
    {
        double percentage = (mileage / MaxMileage) * 100;
        if (this is CargoVan) percentage += 5;
        BatteryLevel -= (int)Math.Round(percentage);
    }

    public void Recharge()
    {
        BatteryLevel = 100;
    }

    public void ChangeStatus()
    {
        IsDamaged = !IsDamaged;
    }

    public override string ToString()
    {
        return $"{Brand} {Model} License plate: {LicensePlateNumber} Battery: {BatteryLevel}% Status: {(IsDamaged ? "damaged" : "OK")}";
    }
}

public class PassengerCar : Vehicle
{
    public PassengerCar(string brand, string model, string licensePlateNumber)
        : base(brand, model, 450, licensePlateNumber)
    {
    }
}

public class CargoVan : Vehicle
{
    public CargoVan(string brand, string model, string licensePlateNumber)
        : base(brand, model, 180, licensePlateNumber)
    {
    }
}
