
using System;
using System.Linq;
using BookingApp.Models.Rooms.Contracts;
using BookingApp.Models.Bookings.Contracts;
using BookingApp.Repositories.Contracts;
using BookingApp.Models.Hotels.Contacts;
using System.Collections.Generic;

namespace BookingApp.Models.Hotels
{
    public class Hotel : IHotel
    {
        public string FullName { get; private set; }
        public int Category { get; private set; }
        public double Turnover => Bookings.All().Sum(b => b.ResidenceDuration * b.Room.PricePerNight);
        public IRepository<IRoom> Rooms { get; private set; }
        public IRepository<IBooking> Bookings { get; private set; }

        public Hotel(string fullName, int category)
        {
            if (string.IsNullOrWhiteSpace(fullName))
            {
                throw new ArgumentException("Hotel name cannot be null or empty!");
            }
            if (category < 1 || category > 5)
            {
                throw new ArgumentException("Category should be between 1 and 5 stars!");
            }

            FullName = fullName;
            Category = category;
            Rooms = new RoomRepository();
            Bookings = new BookingRepository();
        }
    }

    internal class BookingRepository : IRepository<IBooking>
    {
        public void AddNew(IBooking model)
        {
            throw new NotImplementedException();
        }

        public IReadOnlyCollection<IBooking> All()
        {
            throw new NotImplementedException();
        }

        public IBooking Select(string criteria)
        {
            throw new NotImplementedException();
        }
    }

    internal class RoomRepository : IRepository<IRoom>
    {
        public void AddNew(IRoom model)
        {
            throw new NotImplementedException();
        }

        public IReadOnlyCollection<IRoom> All()
        {
            throw new NotImplementedException();
        }

        public IRoom Select(string criteria)
        {
            throw new NotImplementedException();
        }
    }
}
