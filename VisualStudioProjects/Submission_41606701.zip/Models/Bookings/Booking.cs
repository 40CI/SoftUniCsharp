
using System;
using BookingApp.Models.Bookings.Contracts;
using BookingApp.Models.Rooms.Contracts;

namespace BookingApp.Models.Bookings
{
    public class Booking : IBooking
    {
        public int BookingNumber { get; }
        public int ResidenceDuration { get; }
        public int AdultsCount { get; }
        public int ChildrenCount { get; }
        private IRoom Room { get; }

        IRoom IBooking.Room => throw new NotImplementedException();

        public Booking(IRoom room, int residenceDuration, int adultsCount, int childrenCount, int bookingNumber)
        {
            if (residenceDuration <= 0) throw new ArgumentException("Duration cannot be negative or zero!");
            if (adultsCount < 1) throw new ArgumentException("Adults count cannot be negative or zero!");
            if (childrenCount < 0) throw new ArgumentException("Children count cannot be negative!");

            Room = room;
            ResidenceDuration = residenceDuration;
            AdultsCount = adultsCount;
            ChildrenCount = childrenCount;
            BookingNumber = bookingNumber;
        }

        public string BookingSummary()
        {
            double totalPaid = Math.Round(ResidenceDuration * Room.PricePerNight, 2);
            return $"Booking number: {BookingNumber}\nRoom type: {Room.GetType().Name}\n" +
                   $"Adults: {AdultsCount} Children: {ChildrenCount}\nTotal amount paid: {totalPaid:F2} $";
        }
    }
}
