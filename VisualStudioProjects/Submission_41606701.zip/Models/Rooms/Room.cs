
using System;
using BookingApp.Models.Rooms.Contracts;

namespace BookingApp.Models.Rooms
{
    public abstract class Room : IRoom
    {
        public int BedCapacity { get; private set; }
        public double PricePerNight { get; private set; }

        protected Room(int bedCapacity)
        {
            BedCapacity = bedCapacity;
            PricePerNight = 0;
        }

        public void SetPrice(double price)
        {
            if (price < 0)
                throw new ArgumentException("Price cannot be negative!");
            PricePerNight = price;
        }
    }

    public class DoubleBed : Room
    {
        public DoubleBed() : base(2) { }
    }

    public class Studio : Room
    {
        public Studio() : base(4) { }
    }

    public class Apartment : Room
    {
        public Apartment() : base(6) { }
    }
}
